Dependencies
============

[Moment.js](http://momentjs.com/)

Usage
====

See the [MomentCell](http://wyuenho.github.com/backgrid/#api-moment-cell) section
in the documentation.
