Dependencies
============

[bootstrap-modal.js](http://twitter.github.com/bootstrap/javascript.html#modals)

Usage
====

See the [TextCell](http://wyuenho.github.com/backgrid/#api-text-cell) section in
the documentation.
